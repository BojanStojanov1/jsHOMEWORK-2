let year = prompt("how many old are you")
let zondiacSign = ((year - 4)/12)
if (zondiacSign >= 0 && zondiacSign <=0.9){
    console.log ('Rat')
}
else if (zondiacSign >= 1 && zondiacSign <=1.9){
    console.log('Ox')
}
else if (zondiacSign >= 2 && zondiacSign <=2.9){
    console.log('Tiger')
}
else if (zondiacSign >= 3 && zondiacSign <=3.9){
    console.log('Rabbit')
}
else if (zondiacSign >= 4 && zondiacSign <=4.9){
    console.log('Dragon')
}
else if (zondiacSign >= 5 && zondiacSign <=5.9){
    console.log('Snake')
}
else if (zondiacSign >= 6 && zondiacSign <=6.9){
    console.log('Horse')
}
else if (zondiacSign >= 7 && zondiacSign <=7.9){
    console.log('Goat')
}
else if (zondiacSign >= 8 && zondiacSign <=8.9){
    console.log('Monkey')
}
else if (zondiacSign >= 9 && zondiacSign <=9.9){
    console.log('Rooster')
}
else if (zondiacSign >= 10 && zondiacSign <=10.9){
    console.log('Dog')
}
else if (zondiacSign >= 11 && zondiacSign <=11.9){
    console.log('Pig')
}